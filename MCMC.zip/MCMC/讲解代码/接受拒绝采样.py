import numpy as np
import matplotlib.pyplot as plt

# 定义目标分布（已归一化）
def f(x):
    return 1.2 - x**4

# 理论概率密度函数（已验证积分=1）
def pdf(x):
    return f(x)

# 接受-拒绝采样（向量化版本，提高速度）
def sample(f, xmin=0, xmax=1, ymax=1.2, num_samples=1):
    samples = []
    while len(samples) < num_samples:
        x = np.random.uniform(xmin, xmax, size=num_samples*2)  # 预生成更多候选
        y = np.random.uniform(0, ymax, size=num_samples*2)
        accept = y < f(x)
        samples.extend(x[accept].tolist())
    return np.array(samples[:num_samples])

# 生成样本
samples = sample(f, num_samples=100000)

# 绘制结果
plt.figure(figsize=(10, 5))
xs = np.linspace(0, 1, 1000)
plt.plot(xs, pdf(xs), 'r-', lw=2, label='Theory PDF: $p(x)=1.2-x^4$')
plt.hist(samples, bins=50, density=True, alpha=0.6, color='green', label='Samples')
plt.xlabel('x')
plt.ylabel('Density')
plt.ylim(0, 1.3)
plt.legend()
plt.show()