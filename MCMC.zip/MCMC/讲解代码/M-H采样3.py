import numpy as np
import matplotlib.pyplot as plt
import time

# 目标分布：标准正态分布
def target_dist(x):
    return np.exp(-x**2 / 2) / np.sqrt(2 * np.pi)

# 提议分布 Q：生成候选样本（对称的）
def proposal_distribution(x_t, sigma=1):
    return np.random.normal(x_t, sigma)

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows系统中文支持
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 参数设置
n1 = 500  # burn-in 样本数
n2 = 1000  # 实际采样数
total_steps = n1 + n2
sigma = 1  # 提议分布的标准差

# 初始化
current_x = np.random.uniform(-5, 5)  # 初始状态
samples = []
accept_count = 0
acceptance_rates = []

# 添加暂停控制变量
paused = False  # 暂停标志

# 定义按键事件回调函数
def on_key(event):
    global paused
    if event.key == ' ':  # 按下空格键切换暂停状态
        paused = not paused
        print(f"已{'暂停' if paused else '恢复'}采样过程")

# 创建图形并绑定按键事件
plt.figure(figsize=(12, 8))
plt.connect('key_press_event', on_key)  # 绑定按键事件

x_range = np.linspace(-4, 4, 1000)
target_y = target_dist(x_range)

# 定义固定的坐标轴范围
x_min, x_max = -4, 4
y_min, y_max = 0, 0.45

# 主循环
for step in range(total_steps):
    while paused:  # 如果处于暂停状态，持续刷新界面但不执行采样
        plt.pause(0.1)  # 刷新界面
    
    # 从提议分布生成候选样本
    x_s = proposal_distribution(current_x, sigma)
    
    # 计算接受概率
    alpha = min(1, target_dist(x_s) / target_dist(current_x))
    
    # 接受或拒绝转移（但不立即更新 current_x）
    u = np.random.uniform(0, 1)
    decision = "拒绝"
    if u < alpha:
        next_x = x_s  # 延迟更新 current_x
        accept_count += 1
        decision = "接受"
    else:
        next_x = current_x  # 保持 current_x 不变
    
    # 将 next_x 添加到样本中（但不立即更新 current_x）
    samples.append(current_x)
    current_accept_rate = accept_count / (step + 1)
    acceptance_rates.append(current_accept_rate)
    
    # 每1步或最后一步更新图表
    if step % 1 == 0 or step == total_steps - 1:
        # 清除当前图表
        plt.clf()
        
        # 创建网格布局
        gs = plt.GridSpec(2, 2)
        
        # 子图1: 采样结果直方图 vs 目标分布 (固定坐标轴)
        ax1 = plt.subplot(gs[0, 0])
        # 先绘制静态的目标分布图（蓝色）
        ax1.plot(x_range, target_dist(x_range), 'b', linewidth=2, label="目标分布 N(0,1)")
        
        # 再绘制动态的直方图
        ax1.hist(samples, bins=100, density=True, alpha=0.6, color='orange', label="MCMC样本")
        
        # 新增：绘制提议分布曲线和样本点
        # 计算以当前点为中心的提议分布曲线
        proposal_curve = 1/(sigma * np.sqrt(2 * np.pi)) * np.exp(-(x_range - current_x)**2/(2 * sigma**2))
        ax1.plot(x_range, proposal_curve, 'm--', linewidth=1.5, alpha=0.7, label="提议分布 Q(x|xt)")
        
        # 标记当前候选点的提议分布高度
        proposal_height = 1/(sigma * np.sqrt(2 * np.pi)) * np.exp(-(x_s - current_x)**2/(2 * sigma**2))
        ax1.plot([x_s, x_s], [0, proposal_height], 'c-', linewidth=2, alpha=0.7, label="采样位置")
        
        # 标记当前点和候选点
        ax1.plot([current_x], [target_dist(current_x)], 'bo', markersize=8, label="当前点")
        ax1.plot([x_s], [target_dist(x_s)], 'go' if decision == "接受" else 'ro', markersize=8, 
                 label=f"候选点 ({decision})")
        
        # 添加水平横线表示接受概率α
        # 计算α在目标分布上的高度位置
        alpha_height = max(target_dist(current_x), target_dist(x_s)) * alpha
        ax1.axhline(y=alpha_height, color='red', linestyle=':', alpha=0.7,
                   label=f"接受概率 α={alpha:.4f}")
        
        # 在决策点处显示随机数u
        # 如果是接受决策，就在候选点处显示u
        # 如果是拒绝决策，就在当前点处显示u
        if decision == "接受":
            u_height = alpha_height * u / alpha if alpha > 0 else 0
            u_label = "接受点 u值"
            u_point = [x_s]
        else:
            # 拒绝决策时，在当前点处显示u值
            u_height = target_dist(current_x) * u
            u_label = "拒绝点 u值"
            u_point = [current_x]
        
        # 在决策点处标记u值
        ax1.plot(u_point, [u_height], 'c*', markersize=15, 
                 label=f"{u_label}: {u:.4f}")
        
        # 添加从决策点到u点的虚线
        if decision == "接受":
            ax1.plot([x_s, x_s], [target_dist(x_s), u_height], 
                     'c--', alpha=0.6)
        else:
            ax1.plot([current_x, current_x], [target_dist(current_x), u_height], 
                     'c--', alpha=0.6)

        ax1.set_title(f"采样分布 (样本数: {step+1})")
        ax1.set_xlabel("x")
        ax1.set_ylabel("概率密度")
        ax1.legend(loc='upper right')
        ax1.grid(alpha=0.3)
        ax1.set_xlim(x_min, x_max)  # 固定x轴范围
        ax1.set_ylim(y_min, y_max)  # 固定y轴范围
        
        # 子图2: 样本轨迹
        ax2 = plt.subplot(gs[0, 1])
        ax2.plot(range(step+1), samples, 'b-', alpha=0.7)
        # 标记当前点
        ax2.plot(step, current_x, 'ro' if decision == "拒绝" else 'go', markersize=8)
        
        # 标记burn-in结束点
        if step >= n1:
            ax2.axvline(x=n1, color='r', linestyle='--', alpha=0.7)
            ax2.text(n1, max(samples) if samples else 0, f'burn-in结束', color='r')
        ax2.set_title(f"样本轨迹 (当前值: {current_x:.2f})")
        ax2.set_xlabel("采样次数")
        ax2.set_ylabel("样本值")
        ax2.grid(alpha=0.3)
        
        # 子图3: 接受率变化
        ax3 = plt.subplot(gs[1, 0])
        ax3.plot(range(step+1), acceptance_rates, 'g-')
        ax3.set_ylim(0, 1)
        ax3.set_title(f"接受率变化 (当前: {current_accept_rate:.3f})")
        ax3.set_xlabel("采样次数")
        ax3.set_ylabel("接受率")
        ax3.grid(alpha=0.3)
        
        # 子图4: 当前点详情
        ax4 = plt.subplot(gs[1, 1])
        ax4.axis('off')
        info_text = (
            f"当前采样数: {step+1}/{total_steps}\n"
            f"当前样本值: {current_x:.4f}\n"
            f"候选样本值: {x_s:.4f}\n"
            f"目标密度比: π(x*)/π(xt) = {target_dist(x_s)/target_dist(current_x):.4f}\n"
            f"接受概率 α: {alpha:.4f}\n"
            f"随机数 u: {u:.4f}\n"
            f"决策: {decision}\n"
            f"累计接受率: {current_accept_rate:.4f}\n"
            f"阶段: {'预烧期' if step < n1 else '采样期'}\n"
            f"提议标准差: {sigma:.2f}"
        )
        ax4.text(0.05, 0.5, info_text, fontsize=12, 
                bbox=dict(facecolor='lightblue', alpha=0.5))
        
        plt.suptitle(f"Metropolis-Hastings 采样过程 (步骤 {step+1}/{total_steps})", fontsize=16)
        plt.tight_layout()
        plt.subplots_adjust(top=0.92)
        
        # 短暂暂停以显示图表
        plt.pause(0.001)  # 快速刷新界面
        
        # 最后一步保持显示
        if step == total_steps - 1:
            plt.show(block=True)
        else:
            plt.draw()

    # 延迟更新 current_x（在下一次迭代中生效）
    current_x = next_x

# 返回最终采样结果（去除burn-in）
final_samples = samples[n1:]
print(f"采样完成! 总样本数: {total_steps}, 有效样本: {n2}, 最终接受率: {accept_count/total_steps:.4f}")