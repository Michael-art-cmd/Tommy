import numpy as np
import matplotlib.pyplot as plt

# 设置随机种子（保证可重复性）
np.random.seed(42)

# 生成n=10000个Uniform(0,1)的样本
n = 10000
u1 = np.random.uniform(0, 1, n)
u2 = np.random.uniform(0, 1, n)

# 合并为二维均匀分布样本
uniform_samples = np.column_stack((u1, u2))

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 首先绘制二维均匀分布散点图
plt.figure(figsize=(8, 8))
plt.scatter(uniform_samples[:, 0], uniform_samples[:, 1], alpha=0.5, s=5, color='green', label='均匀分布样本')
plt.title('二维均匀分布散点图（[0,1]×[0,1]区间）')
plt.xlabel('X轴')
plt.ylabel('Y轴')
plt.xlim(0, 1)
plt.ylim(0, 1)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.show()

# Box-Muller变换：将均匀分布转换为标准正态分布
z0 = np.sqrt(-2 * np.log(u1)) * np.cos(2 * np.pi * u2)
z1 = np.sqrt(-2 * np.log(u1)) * np.sin(2 * np.pi * u2)

# 合并为二维正态分布样本（均值为0，协方差矩阵为单位矩阵）
samples = np.column_stack((z0, z1))

# 然后绘制二维正态分布散点图
plt.figure(figsize=(10, 8))
plt.scatter(samples[:, 0], samples[:, 1], alpha=0.5, s=5, color='blue', label='转换后的样本点')

# 添加理论等高线（红色虚线）
x = np.linspace(-4, 4, 100)
y = np.linspace(-4, 4, 100)
X, Y = np.meshgrid(x, y)
Z = (1 / (2 * np.pi)) * np.exp(-0.5 * (X**2 + Y**2))  # 二维标准正态分布密度函数
plt.contour(X, Y, Z, levels=5, colors='red', linestyles='dashed', linewidths=1, label='理论等高线')

# 美化图表
plt.title('二维标准正态分布散点图（通过均匀分布转换生成）')
plt.xlabel('X轴')
plt.ylabel('Y轴')
plt.xlim(-4, 4)
plt.ylim(-4, 4)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.show()