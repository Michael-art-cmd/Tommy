import numpy as np
import matplotlib.pyplot as plt
import time
from scipy.stats import multivariate_normal, norm

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows系统中文支持
plt.rcParams['axes.unicode_minus'] = False    # 解决负号显示问题

# 目标分布：二维正态分布
def target_distribution():
    # 设置均值向量
    mean = np.array([0.0, 0.0])
    
    # 设置协方差矩阵（引入相关性）
    covariance = np.array([[1.0, 0.8],  # 正相关
                          [0.8, 1.0]])
    
    return multivariate_normal(mean=mean, cov=covariance)

# 参数设置
n1 = 100  # burn-in 样本数
n2 = 500  # 实际采样数
total_steps = n1 + n2

# 初始化状态
x = np.random.uniform(-3, 3)
y = np.random.uniform(-3, 3)

samples = []
current_accept_rates = []  # 每次转移后被接受的比例

# 设置目标分布
target_dist = target_distribution()
cov = target_dist.cov
mean = target_dist.mean

# 计算条件分布参数
sigma_x = np.sqrt(cov[0, 0])
sigma_y = np.sqrt(cov[1, 1])
rho = cov[0, 1] / (sigma_x * sigma_y)  # 相关系数

# 创建图形
plt.figure(figsize=(15, 10))

# 定义坐标轴范围
x_min, x_max = -4, 4
y_min, y_max = -4, 4

# 生成网格用于绘制目标分布
x_grid = np.linspace(x_min, x_max, 100)
y_grid = np.linspace(y_min, y_max, 100)
X, Y = np.meshgrid(x_grid, y_grid)
pos = np.dstack((X, Y))
Z = target_dist.pdf(pos)

# 主循环
for step in range(total_steps):
    # 记录前一点用于可视化
    prev_x, prev_y = x, y
    
    # 固定y，采样x的条件分布 p(x|y)
    mean_x_given_y = mean[0] + rho * (sigma_x / sigma_y) * (y - mean[1])
    var_x_given_y = sigma_x**2 * (1 - rho**2)
    x = np.random.normal(mean_x_given_y, np.sqrt(var_x_given_y))
    
    # 固定x，采样y的条件分布 p(y|x)
    mean_y_given_x = mean[1] + rho * (sigma_y / sigma_x) * (x - mean[0])
    var_y_given_x = sigma_y**2 * (1 - rho**2)
    y = np.random.normal(mean_y_given_x, np.sqrt(var_y_given_x))
    
    # 记录样本
    samples.append([x, y])
    current_accept_rates.append(1.0)  # Gibbs采样始终接受
    
    # 每步更新图表
    if step % 1 == 0 or step == total_steps - 1:
        # 清除当前图表
        plt.clf()
        
        # 创建网格布局
        gs = plt.GridSpec(3, 2)
        
        # 子图1: 二维采样分布
        ax1 = plt.subplot(gs[0:2, 0])
        
        # 绘制目标分布等高线
        levels = np.linspace(Z.min(), Z.max(), 20)
        ax1.contour(X, Y, Z, levels=levels, alpha=0.5, colors='blue')
        
        # 绘制采样轨迹
        if samples:
            samples_arr = np.array(samples)
            ax1.plot(samples_arr[:, 0], samples_arr[:, 1], 'g-', alpha=0.3, linewidth=0.5)
            ax1.scatter(samples_arr[0:-1, 0], samples_arr[0:-1, 1], c='blue', s=15, alpha=0.5)
            ax1.scatter(samples_arr[-1, 0], samples_arr[-1, 1], c='red', s=40, label='当前点')
        
        # 标记burn-in结束点
        if step == n1 and samples:
            ax1.scatter(samples[n1][0], samples[n1][1], c='yellow', s=100, marker='*', label='Burn-in结束')
        
        # 绘制当前采样路径
        ax1.plot([prev_x, x], [prev_y, prev_y], 'm-', linewidth=2, alpha=0.7)  # x方向的转移
        ax1.plot([x, x], [prev_y, y], 'c-', linewidth=2, alpha=0.7)  # y方向的转移
        
        ax1.set_title(f"采样分布 (步骤: {step+1}/{total_steps})")
        ax1.set_xlabel("X")
        ax1.set_ylabel("Y")
        ax1.set_xlim(x_min, x_max)
        ax1.set_ylim(y_min, y_max)
        ax1.legend()
        ax1.grid(alpha=0.3)
        
        # 子图2: X变量采样轨迹
        ax2 = plt.subplot(gs[0, 1])
        if samples:
            samples_arr = np.array(samples)
            ax2.plot(range(step+1), samples_arr[:, 0], 'b-', alpha=0.7)
            # 标记当前点
            ax2.scatter(step, samples_arr[step, 0], c='r', s=40)
            
            # 标记burn-in结束点
            if step >= n1:
                ax2.axvline(x=n1, color='r', linestyle='--', alpha=0.7)
                ax2.text(n1, ax2.get_ylim()[0], 'Burn-in结束', color='r')
        
        ax2.set_title(f"X变量轨迹 (当前值: {x:.2f})")
        ax2.set_xlabel("迭代次数")
        ax2.set_ylabel("X值")
        ax2.grid(alpha=0.3)
        
        # 子图3: Y变量采样轨迹
        ax3 = plt.subplot(gs[1, 1])
        if samples:
            ax3.plot(range(step+1), samples_arr[:, 1], 'g-', alpha=0.7)
            # 标记当前点
            ax3.scatter(step, samples_arr[step, 1], c='r', s=40)
            
            # 标记burn-in结束点
            if step >= n1:
                ax3.axvline(x=n1, color='r', linestyle='--', alpha=0.7)
                ax3.text(n1, ax3.get_ylim()[0], 'Burn-in结束', color='r')
        
        ax3.set_title(f"Y变量轨迹 (当前值: {y:.2f})")
        ax3.set_xlabel("迭代次数")
        ax3.set_ylabel("Y值")
        ax3.grid(alpha=0.3)
        
        # 子图4: X的条件分布
        ax4 = plt.subplot(gs[2, 0])
        if step > 0:
            # 绘制X的条件分布：p(x|y)
            x_cond_range = np.linspace(x_min, x_max, 100)
            x_cond_pdf = norm.pdf(x_cond_range, loc=mean_x_given_y, scale=np.sqrt(var_x_given_y))
            
            # 绘制真实边缘分布
            true_x_marginal = norm.pdf(x_cond_range, loc=0, scale=1)
            
            ax4.plot(x_cond_range, x_cond_pdf, 'r-', label='p(X|Y)条件分布')
            ax4.plot(x_cond_range, true_x_marginal, 'b--', label='真实边缘分布')
            
            # 标记当前点和采样点
            ax4.axvline(x, color='red', linestyle='-', alpha=0.7)
            ax4.text(x, ax4.get_ylim()[1]*0.9, f'采样值: {x:.2f}', color='red')
            
            ax4.set_title(f"X的条件分布 (固定Y={y:.2f})")
            ax4.set_xlabel("X值")
            ax4.set_ylabel("概率密度")
            ax4.legend()
            ax4.grid(alpha=0.3)
        
        # 子图5: Y的条件分布
        ax5 = plt.subplot(gs[2, 1])
        if step > 0:
            # 绘制Y的条件分布：p(y|x)
            y_cond_range = np.linspace(y_min, y_max, 100)
            y_cond_pdf = norm.pdf(y_cond_range, loc=mean_y_given_x, scale=np.sqrt(var_y_given_x))
            
            # 绘制真实边缘分布
            true_y_marginal = norm.pdf(y_cond_range, loc=0, scale=1)
            
            ax5.plot(y_cond_range, y_cond_pdf, 'r-', label='p(Y|X)条件分布')
            ax5.plot(y_cond_range, true_y_marginal, 'b--', label='真实边缘分布')
            
            # 标记当前点和采样点
            ax5.axvline(y, color='red', linestyle='-', alpha=0.7)
            ax5.text(y, ax5.get_ylim()[1]*0.9, f'采样值: {y:.2f}', color='red')
            
            ax5.set_title(f"Y的条件分布 (固定X={x:.2f})")
            ax5.set_xlabel("Y值")
            ax5.set_ylabel("概率密度")
            ax5.legend()
            ax5.grid(alpha=0.3)
        
        plt.suptitle(f"吉布斯采样过程 (步骤 {step+1}/{total_steps})", fontsize=16)
        plt.tight_layout()
        plt.subplots_adjust(top=0.93)
        
        # 短暂暂停以显示图表
        plt.pause(1)
        
        # 最后一步保持显示
        if step == total_steps - 1:
            plt.show(block=True)
        else:
            plt.draw()

# 返回最终采样结果（去除burn-in）
samples_arr = np.array(samples)
final_samples = samples_arr[n1:]

print(f"采样完成! 总样本数: {total_steps}, 有效样本: {len(final_samples)}")
print(f"样本均值: [{np.mean(final_samples[:,0]):.4f}, {np.mean(final_samples[:,1]):.4f}]")
print(f"样本协方差: [{np.cov(final_samples, rowvar=False)[0,0]:.4f}, {np.cov(final_samples, rowvar=False)[0,1]:.4f}]")