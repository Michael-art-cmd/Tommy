import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

# 目标分布：标准正态分布
def target_dist(x):
    return np.exp(-x**2 / 2) / np.sqrt(2 * np.pi)

# 提议分布 Q：生成候选样本（对称的）
def proposal_distribution(x_t, sigma=1):
    return np.random.normal(x_t, sigma)

# Metropolis-Hastings 算法
def metropolis_hastings(n1, n2):
    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows系统中文支持
    plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
    
    samples = []
    accepted = []  # 记录接受状态
    current_x = np.random.uniform(-5, 5)  # 初始状态
    
    # 创建动态更新图表
    plt.figure(figsize=(12, 8))
    gs = GridSpec(3, 2)
    
    # 绘制目标分布
    ax1 = plt.subplot(gs[0, :])
    x_range = np.linspace(-4, 4, 1000)
    target_y = target_dist(x_range)
    ax1.plot(x_range, target_y, 'r-', linewidth=2, label="目标分布 N(0,1)")
    ax1.set_title("目标分布 (标准正态分布)")
    ax1.set_xlabel("x")
    ax1.set_ylabel("概率密度")
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    
    # 采样过程
    ax2 = plt.subplot(gs[1, :])
    ax2.set_title("MCMC 采样过程")
    ax2.set_xlabel("采样次数")
    ax2.set_ylabel("样本值")
    ax2.grid(True, alpha=0.3)
    
    # 结果直方图
    ax3 = plt.subplot(gs[2, 0])
    ax3.set_title("采样结果直方图")
    ax3.set_xlabel("x")
    ax3.set_ylabel("采样数")
    
    # 接受率显示
    ax4 = plt.subplot(gs[2, 1])
    ax4.set_title("接受率变化")
    ax4.set_xlabel("采样次数")
    ax4.set_ylabel("接受率")
    ax4.set_ylim(0, 1)
    ax4.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # 采样循环
    accept_count = 0
    acceptance_rates = []
    
    for i in range(1, n1 + n2 + 1):
        # 从提议分布生成候选样本
        x_s = proposal_distribution(current_x)
        
        # 计算接受概率
        alpha = min(1, target_dist(x_s) / target_dist(current_x))
        
        # 接受或拒绝转移
        u = np.random.uniform(0, 1)
        if u < alpha:
            current_x = x_s
            accept_count += 1
            accepted.append(True)
        else:
            accepted.append(False)
            
        samples.append(current_x)
        
        # 每100步更新一次图表
        if i % 100 == 0 or i == n1 + n2:
            # 计算当前接受率
            current_rate = accept_count / i
            acceptance_rates.append(current_rate)
            
            # 更新采样过程图
            ax2.clear()
            ax2.plot(range(i), samples[:i], 'b-', alpha=0.6)
            ax2.set_title(f"MCMC 采样过程 (采样次数: {i})")
            ax2.set_xlabel("采样次数")
            ax2.set_ylabel("样本值")
            ax2.grid(True, alpha=0.3)
            
            # 更新接受率图
            ax4.clear()
            ax4.plot(range(0, i, 100), acceptance_rates, 'g-')
            ax4.set_title(f"接受率变化 (当前: {current_rate:.2f})")
            ax4.set_xlabel("采样次数")
            ax4.set_ylabel("接受率")
            ax4.set_ylim(0, 1)
            ax4.grid(True, alpha=0.3)
            
            # 更新直方图
            ax3.clear()
            ax3.hist(samples, bins=50, alpha=0.6, color='blue')
            ax3.set_title(f"采样结果直方图 (样本数: {i})")
            ax3.set_xlabel("x")
            ax3.set_ylabel("采样数")
            
            # 添加目标分布到直方图
            ax3_twin = ax3.twinx()
            ax3_twin.plot(x_range, target_y, 'r-', linewidth=2)
            ax3_twin.set_ylabel("概率密度", color='r')
            ax3_twin.tick_params(axis='y', labelcolor='r')
            
            plt.pause(0.01)  # 短暂暂停以更新图表
    
    plt.tight_layout()
    plt.show()
    
    # 返回采样结果
    return samples, accepted

# 运行算法
burn_in = 500  # 预烧期样本数
n_samples = 5000  # 实际采样数
samples, accepted = metropolis_hastings(burn_in, n_samples)
