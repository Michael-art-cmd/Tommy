import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows系统中文支持
plt.rcParams['axes.unicode_minus'] = False    # 解决负号显示问题

# 目标分布：二维正态分布
def target_distribution():
    # 设置均值向量
    mean = np.array([0.0, 0.0])
    
    # 设置协方差矩阵（引入相关性）
    covariance = np.array([[1.0, 0.8],  # 正相关
                           [0.8, 1.0]])
    
    return multivariate_normal(mean=mean, cov=covariance)

# 吉布斯采样算法
def gibbs_sampling(n1, n2):
    # 初始化状态 (随机初始化)
    x = np.random.uniform(-3, 3)
    y = np.random.uniform(-3, 3)
    
    samples = []
    
    # 计算条件分布的参数
    cov = target_distribution().cov
    mean = target_distribution().mean
    sigma_x = np.sqrt(cov[0, 0])  # x的标准差
    sigma_y = np.sqrt(cov[1, 1])  # y的标准差
    rho = cov[0, 1] / (sigma_x * sigma_y)  # 相关系数
    
    # 主采样循环
    for i in range(n1 + n2):
        # 固定y，采样x的条件分布 p(x|y)
        mean_x_given_y = mean[0] + rho * (sigma_x / sigma_y) * (y - mean[1])
        var_x_given_y = sigma_x**2 * (1 - rho**2)
        x = np.random.normal(mean_x_given_y, np.sqrt(var_x_given_y))
        
        # 固定x，采样y的条件分布 p(y|x)
        mean_y_given_x = mean[1] + rho * (sigma_y / sigma_x) * (x - mean[0])
        var_y_given_x = sigma_y**2 * (1 - rho**2)
        y = np.random.normal(mean_y_given_x, np.sqrt(var_y_given_x))
        
        samples.append([x, y])
    
    # 转换为NumPy数组并移除burn-in期
    samples = np.array(samples)
    return samples[n1:]

# 参数设置
n1 = 500     # burn-in 样本数
n2 = 10000   # 实际采样数

# 运行吉布斯采样
samples = gibbs_sampling(n1, n2)

# 生成目标分布的真实密度网格
x_min, x_max = -3, 3
y_min, y_max = -3, 3
x_grid = np.linspace(x_min, x_max, 100)
y_grid = np.linspace(y_min, y_max, 100)
X, Y = np.meshgrid(x_grid, y_grid)
pos = np.dstack((X, Y))

target_dist = target_distribution()
Z = target_dist.pdf(pos)

# 创建3D图形展示结果
fig = plt.figure(figsize=(15, 12))

# 1. 采样点三维分布图
ax1 = fig.add_subplot(221, projection='3d')
ax1.plot_surface(X, Y, Z, cmap='viridis', alpha=0.8)
ax1.scatter(samples[:, 0], samples[:, 1], 
            target_dist.pdf(np.column_stack([samples[:, 0], samples[:, 1]])),
            c='red', s=1, alpha=0.5)
ax1.set_title('三维采样点分布')
ax1.set_xlabel('X轴')
ax1.set_ylabel('Y轴')
ax1.set_zlabel('概率密度')
ax1.view_init(elev=25, azim=55)

# 2. 采样点散点图
ax2 = fig.add_subplot(222)
ax2.scatter(samples[:, 0], samples[:, 1], s=1, alpha=0.5)
ax2.set_title('采样点散点图')
ax2.set_xlabel('X轴')
ax2.set_ylabel('Y轴')
ax2.grid(True)

# 3. 采样点等高线图
ax3 = fig.add_subplot(223)
ax3.contourf(X, Y, Z, levels=20, cmap='viridis')
ax3.set_title('目标分布等高线图')
ax3.set_xlabel('X轴')
ax3.set_ylabel('Y轴')

# 4. X变量的边缘分布
ax4 = fig.add_subplot(224)
ax4.hist(samples[:, 0], bins=50, density=True, alpha=0.6, label="采样分布")
x_marginal = np.linspace(-3, 3, 100)
ax4.plot(x_marginal, target_dist.pdf(np.column_stack([x_marginal, np.zeros_like(x_marginal)])))
ax4.set_title('X变量边缘分布')
ax4.set_xlabel('X值')
ax4.set_ylabel('概率密度')
ax4.legend()

plt.tight_layout()
plt.show()

# 打印相关系数分析
x_cor = np.corrcoef(samples[:, 0], samples[:, 1])[0, 1]
print(f"采样点的相关系数: {x_cor:.4f}")
print(f"目标分布的相关系数: {target_dist.cov[0,1]:.4f}")