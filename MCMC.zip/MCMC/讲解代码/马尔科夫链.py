import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.colors import LinearSegmentedColormap
import time

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows系统中文支持
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 初始化参数
np.random.seed(42)  # 确保结果可重现
n_rooms = 26  # 26个房间
total_steps = 500  # 总步数

# 创建房间数据
rooms = [chr(ord('A') + i) for i in range(n_rooms)]  # 房间A-Z
# 创建不均匀的人数分布（从1到100递增）
populations = np.linspace(1, 100, n_rooms, dtype=int)
np.random.shuffle(populations)  # 打乱分布，不再按字母顺序排序
populations_dict = {room: pop for room, pop in zip(rooms, populations)}

# 创建随机相邻关系（每个房间有2-4个相邻房间）
adjacency = {}
for room in rooms:
    # 随机选择2-4个相邻房间
    possible_neighbors = [r for r in rooms if r != room]
    num_neighbors = np.random.randint(2, 5)
    neighbors = np.random.choice(possible_neighbors, num_neighbors, replace=False)
    adjacency[room] = list(neighbors)

# 随机位置布局（模拟城堡结构）
room_positions = {}
for i, room in enumerate(rooms):
    angle = 2 * np.pi * i / n_rooms
    radius = 0.5 + 0.3 * np.random.random()  # 随机半径
    room_positions[room] = (radius * np.cos(angle), radius * np.sin(angle))

# 转移函数：基于房间人数决定下一个房间
def move(current, populations_dict, adjacency):
    neighbors = adjacency[current]
    weights = [populations_dict[n]**1.5 for n in neighbors]  # 使用1.5次方增强高人数房间的吸引力
    weights = np.array(weights) / sum(weights)  # 归一化
    return np.random.choice(neighbors, p=weights)

# 初始化模拟
current_room = np.random.choice(rooms)  # 随机起始房间
visits = {room: 0 for room in rooms}  # 访问计数器
visit_history = []  # 记录每一步的访问房间
acceptance_rates = []  # 接受率历史
accept_count = 0  # 接受转移次数

# 准备可视化布局
plt.figure(figsize=(15, 10))
gs = plt.GridSpec(2, 2, width_ratios=[1.5, 1], height_ratios=[0.6, 1])

# 创建自定义颜色映射
colors = [(0, 0.5, 0), (1, 1, 0.2), (1, 0.4, 0)]  # 绿色 -> 黄色 -> 红色
cmap = LinearSegmentedColormap.from_list("custom_map", colors)

# 主循环
for step in range(total_steps):
    # 记录当前房间
    visits[current_room] += 1
    visit_history.append(current_room)
    
    # 获取当前房间的邻居
    neighbors = adjacency[current_room]
    
    # 计算邻居的权重
    weights = [populations_dict[n]**1.5 for n in neighbors]
    total_weight = sum(weights)
    probabilities = [w/total_weight for w in weights]
    
    # 创建邻居-概率映射字典
    neighbor_probs = dict(zip(neighbors, probabilities))
    
    # 选择下一个房间
    next_room = move(current_room, populations_dict, adjacency)
    
    # 更新接受率（实际上每一步都接受了转移）
    accept_count += 1
    acceptance_rate = accept_count / (step + 1)
    acceptance_rates.append(acceptance_rate)
    
    # 清除当前图表
    plt.clf()
    
    # 1. 创建城堡布局视图
    ax1 = plt.subplot(gs[0:2, 0])
    ax1.set_title(f"城堡房间布局 (步数: {step+1}/{total_steps}, 当前房间: {current_room}, 人数: {populations_dict[current_room]})")
    ax1.set_aspect('equal')
    ax1.axis('off')
    
    # 绘制房间和连接
    max_pop = max(populations)
    for room, neighbors in adjacency.items():
        x, y = room_positions[room]
        # 设置房间大小基于人数
        size = 0.08 + 0.07 * (populations_dict[room] / max_pop)
        # 设置房间颜色基于访问次数
        visit_count = visits[room]
        max_visits = max(1, max(visits.values()))  # 防止除以0
        color_val = visit_count / max_visits
        circle = plt.Circle((x, y), size, color=cmap(color_val))
        ax1.add_patch(circle)
        
        # 标注房间号和人数
        ax1.text(x, y, f"{room}\n{populations_dict[room]}", 
                 ha='center', va='center', fontsize=9, 
                 color='black' if visit_count > max_visits*0.3 else 'white')
        
        # 连接房间
        for neighbor in neighbors:
            nx, ny = room_positions[neighbor]
            # 计算连接线宽度基于人数
            line_width = 0.1 + 0.9 * (populations_dict[neighbor] / max_pop)
            
            # 如果当前房间在邻居中，使用不同颜色
            if neighbor == next_room:
                ax1.plot([x, nx], [y, ny], 'r-', linewidth=line_width, alpha=0.7)
            elif neighbor == current_room:
                ax1.plot([x, nx], [y, ny], 'b-', linewidth=line_width, alpha=0.7)
            else:
                ax1.plot([x, nx], [y, ny], 'k-', linewidth=line_width*0.7, alpha=0.3)
    
    # 高亮当前房间
    cx, cy = room_positions[current_room]
    highlight = plt.Circle((cx, cy), size*1.3, color='blue', fill=False, linewidth=3)
    ax1.add_patch(highlight)
    
    # 高亮下一个房间
    if next_room in room_positions:
        nx, ny = room_positions[next_room]
        arrow = patches.FancyArrowPatch((cx, cy), (nx, ny), 
                                        arrowstyle='->', mutation_scale=20, 
                                        color='red', linewidth=2)
        ax1.add_patch(arrow)
        highlight_next = plt.Circle((nx, ny), size*1.1, color='red', fill=False, linewidth=2.5)
        ax1.add_patch(highlight_next)
    
    # 2. 显示访问频率
    ax2 = plt.subplot(gs[0, 1])
    ax2.set_title(f"房间访问频率 (当前步数: {step+1})")
    
    # 准备数据
    room_labels = list(rooms)
    frequencies = [visits[r] for r in room_labels]
    adjusted_frequencies = frequencies / np.sum(frequencies) * np.sum(populations)
    
    # 创建双条形图
    x = np.arange(len(room_labels))
    width = 0.35
    
    ax2.bar(x - width/2, populations, width, color='skyblue', label='实际人数')
    ax2.bar(x + width/2, adjusted_frequencies, width, color='orange', alpha=0.7, label='模拟比例')
    
    # 仅标注当前房间
    current_idx = room_labels.index(current_room)
    ax2.text(current_idx - width/2, populations[current_idx] + 0.5, 
             f'{populations[current_idx]}', ha='center')
    ax2.text(current_idx + width/2, adjusted_frequencies[current_idx] + 0.5, 
             f'{adjusted_frequencies[current_idx]:.1f}', ha='center')
    
    ax2.set_xticks(x)
    ax2.set_xticklabels(room_labels, rotation=90)
    ax2.set_ylabel('人数/比例')
    ax2.legend()
    ax2.grid(alpha=0.3)
    
    # 3. 显示转移决策信息
    ax3 = plt.subplot(gs[1, 1])
    ax3.axis('off')
    
    # 创建决策信息框
    info_text = [
        f"当前房间: {current_room} ({populations_dict[current_room]}人)",
        f"选择下一个房间: {next_room} ({populations_dict[next_room]}人)",
        "",
        "当前房间的邻居和转移概率:"
    ]
    
    # 添加邻居信息 - 使用字典确保正确匹配
    for neighbor, prob in neighbor_probs.items():
        info_text.append(f"  {neighbor}: {populations_dict[neighbor]}人 → 概率: {prob*100:.1f}%")
    
    info_text.extend([
        "",
        f"累计访问统计:",
        f"  最常访问的房间: {max(visits, key=visits.get)} ({max(visits.values())}次)",
        f"  最少访问的房间: {min(visits, key=visits.get)} ({min(visits.values())}次)"
    ])
    
    info_str = "\n".join(info_text)
    
    ax3.text(0.02, 0.98, info_str, fontsize=12, verticalalignment='top',
            bbox=dict(facecolor='lightblue', alpha=0.6, boxstyle='round'))
    
    # 添加马尔可夫链原理说明
    info_text2 = [
        "马尔可夫链原理:",
        "1. 当前位置仅取决于前一个位置",
        "2. 转移概率与目标分布成比例",
        "3. 经过充分转移后，",
        "   停留频率≈目标分布比例"
    ]
    info_str2 = "\n".join(info_text2)
    ax3.text(0.60, 0.3, info_str2, fontsize=11, verticalalignment='top',
            bbox=dict(facecolor='lightyellow', alpha=0.6, boxstyle='round'))
    
    # 更新当前房间
    current_room = next_room
    
    # 调整布局并显示
    plt.tight_layout()
    plt.subplots_adjust(top=0.93)
    plt.draw()
    
    # 短暂暂停（最后一步暂停时间长一点）
    pause_time = 0.5 if step < total_steps - 1 else 3
    plt.pause(pause_time)

# 保存最终结果
plt.savefig('castle_markov_chain.png', dpi=300)
plt.show()

# 结果分析
print("\n模拟完成! 结果分析:")
print(f"总步数: {total_steps}")
print(f"最常访问的房间: {max(visits, key=visits.get)} (人数: {populations_dict[max(visits, key=visits.get)]})")
print(f"最少访问的房间: {min(visits, key=visits.get)} (人数: {populations_dict[min(visits, key=visits.get)]})")

# 计算相关性
actual = np.array([populations_dict[r] for r in rooms])
frequencies = np.array([visits[r] for r in rooms])
scaled_frequencies = frequencies / np.sum(frequencies) * np.sum(actual)

correlation = np.corrcoef(actual, scaled_frequencies)[0, 1]
print(f"实际人数与访问频率的相关系数: {correlation:.4f}")