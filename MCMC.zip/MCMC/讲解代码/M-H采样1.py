import numpy as np
import matplotlib.pyplot as plt

# 目标分布：标准正态分布
def target_dist(x):
    return np.exp(-x**2 / 2) / np.sqrt(2 * np.pi)

# 提议分布 Q：生成候选样本（对称的）
def proposal_distribution(x_t, sigma=1):
    return np.random.normal(x_t, sigma)

# Metropolis-Hastings 算法
def metropolis_hastings(n1, n2):
    samples = []
    current_x = np.random.uniform(-5, 5)  # 初始状态
    
    for _ in range(n1 + n2):
        # 从提议分布生成候选样本
        x_s = proposal_distribution(current_x)
        
        # 计算接受概率
        alpha = min(1, target_dist(x_s) / target_dist(current_x))  # Q 对称时简化为 π(x_s)/π(x_t)
        
        # 接受或拒绝转移
        u = np.random.uniform(0, 1)
        if u < alpha:
            current_x = x_s
        samples.append(current_x)
        
    
    return samples[n1:]  # 去除 burn-in 期

# 参数设置
n1 = 5000  # burn-in 样本数
n2 = 10000  # 实际采样数
samples = metropolis_hastings(n1, n2)

# 设置中文字体（在绘制图表前配置）
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows系统中文支持
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
# 可视化
plt.figure(figsize=(10, 6))
plt.hist(samples, bins=50, density=True, alpha=0.6, label="MCMC 样本")
x_range = np.linspace(-4, 4, 1000)
plt.plot(x_range, target_dist(x_range), 'r', label="目标分布 N(0,1)")
plt.title("Metropolis-Hastings 采样结果 vs 目标分布")
plt.xlabel("x")
plt.ylabel("概率密度")
plt.legend()
plt.show()